package com.fenacobu.VGateway.dto.iso8583xmltemplate;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "atmbalancerequest")
public class BalanceRequestTemplate{
    private String bank;
    private String atm_card_no;
    private String externaltransactionid;
    private String machinetype;

    @XmlElement
    public String getBank() {
        return this.bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    @XmlElement
    public String getAtm_card_no() {
        return this.atm_card_no;
    }

    public void setAtm_card_no(String atm_card_no) {
        this.atm_card_no = atm_card_no;
    }

    @XmlElement
    public String getExternaltransactionid() {
        return this.externaltransactionid;
    }

    public void setExternaltransactionid(String externaltransactionid) {
        this.externaltransactionid = externaltransactionid;
    }

    @XmlElement
    public String getMachinetype() {
        return this.machinetype;
    }

    public void setMachinetype(String machinetype) {
        this.machinetype = machinetype;
    }
}
