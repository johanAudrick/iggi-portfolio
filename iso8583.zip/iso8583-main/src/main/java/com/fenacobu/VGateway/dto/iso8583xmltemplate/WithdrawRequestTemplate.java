package com.fenacobu.VGateway.dto.iso8583xmltemplate;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "apiwithdrawrequest")
public class WithdrawRequestTemplate {
    private String bank;
    private String atm_card_no;
    private String externaltransactionid;
    private String amount;
    private String currency;
    private String machinetype;
    private String institutionid;
    private String transaction_type;
    private String merchantid;

    @XmlElement
    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    @XmlElement
    public String getAtm_card_no() {
        return atm_card_no;
    }

    public void setAtm_card_no(String atm_card_no) {
        this.atm_card_no = atm_card_no;
    }

    @XmlElement
    public String getExternaltransactionid() {
        return externaltransactionid;
    }

    public void setExternaltransactionid(String externaltransactionid) {
        this.externaltransactionid = externaltransactionid;
    }

    @XmlElement
    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    @XmlElement
    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @XmlElement
    public String getMachinetype() {
        return machinetype;
    }

    public void setMachinetype(String machinetype) {
        this.machinetype = machinetype;
    }

    @XmlElement
    public String getInstitutionid() {
        return institutionid;
    }

    public void setInstitutionid(String institutionid) {
        this.institutionid = institutionid;
    }

    @XmlElement
    public String getTransaction_type() {
        return transaction_type;
    }

    public void setTransaction_type(String transaction_type) {
        this.transaction_type = transaction_type;
    }

    @XmlElement
    public String getMerchantid() {
        return merchantid;
    }

    public void setMerchantid(String merchantid) {
        this.merchantid = merchantid;
    }
}
