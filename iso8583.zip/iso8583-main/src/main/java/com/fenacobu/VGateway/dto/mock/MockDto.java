package com.fenacobu.VGateway.dto.mock;

import lombok.Data;

@Data
public class MockDto {
    private String mockText;

    public MockDto(String mockText) {
        this.mockText = mockText;
    }
}
