package com.fenacobu.VGateway.util;

import com.fenacobu.VGateway.config.Iso8583ConfigurationField;
import com.fenacobu.VGateway.config.Iso8583ConfigurationReader;
import com.fenacobu.VGateway.dto.iso8583.Iso8583FieldDto;
import com.fenacobu.VGateway.dto.iso8583.Iso8583MessageDto;
import com.fenacobu.VGateway.dto.iso8583.Iso8583NestedFieldDto;
import com.fenacobu.VGateway.dto.iso8583xmltemplate.BalanceRequestTemplate;
import com.fenacobu.VGateway.dto.iso8583xmltemplate.WithdrawRequestTemplate;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
@AllArgsConstructor
public class Iso8583Util {

    /*  ----------------------------------------------------------------
        ------------------------- CONSTANTS ----------------------------
        ---------------------------------------------------------------- */

    private final Iso8583ConfigurationReader iso8583ConfigurationReader;
    private final Integer LLVAR = 2;
    private final Integer LLLVAR = 3;
    private final Integer MTI_SIZE = 4;
    private final Integer PRIMARY_BITMAP_SIZE = 8;
    private final Integer SECONDARY_BITMAP_SIZE = 8;
    private final Integer GENERAL_NESTED_MESSAGE_ID_SIZE = 3;
    private final Integer GENERAL_NESTED_MESSAGE_LENGTH_SIZE = 3;
    private final String BSWITCH_ENCODE_MECH = "HEX";
    private final String BSWITCH_BANK_NAME = "fenacobu";
    private final String MACHINE_TYPE_ATM = "ATM";
    private final String MACHINE_TYPE_POS = "POS";
    private final String POS_PURCHASE = "purchase";
    private final String POS_CASH_BACK = "purchase_cb";
    private final String POS_CASH_ADVANCE = "cashadv";
    private final String POS_PRE_AUTH = "preauth";
    private final String POS_COMPLETION = "completion";


    /*  ----------------------------------------------------------------
        ---------------------- HELPER FUNCTIONS ------------------------
        ---------------------------------------------------------------- */

    private Integer getMultiplierValueFromMech(String encodeMech) {
        switch (encodeMech) {
            case "HEX":
                return 2;
            default:
                return 1;
        }
    }

    public Integer getConstantValue(String format) {
        switch (format) {
            case "LLVAR":
                return LLVAR;
            case "LLLVAR":
                return LLLVAR;
            case "MTI_SIZE":
                return MTI_SIZE;
            case "PRIMARY_BITMAP_SIZE":
                return PRIMARY_BITMAP_SIZE;
            case "SECONDARY_BITMAP_SIZE":
                return SECONDARY_BITMAP_SIZE;
            case "GENERAL_NESTED_MESSAGE_ID_SIZE":
                return GENERAL_NESTED_MESSAGE_ID_SIZE;
            case "GENERAL_NESTED_MESSAGE_LENGTH_SIZE":
                return GENERAL_NESTED_MESSAGE_LENGTH_SIZE;
            default:
                return LLVAR;
        }
    }

    public String getBswitchEncodeMech() {
        return BSWITCH_ENCODE_MECH;
    }

    public String getBswitchBankName() {
        return BSWITCH_BANK_NAME;
    }

    public String getMachineCode(String transactionType) {
        switch (transactionType) {
            case "00774" :
                return MACHINE_TYPE_POS;
            default:
                return MACHINE_TYPE_ATM;
        }
    }


    public String getTransactionType(String transactionType) {
        switch (transactionType) {
            case "00774" :
                return POS_PURCHASE;
            case "09776":
                return POS_CASH_BACK;
            case "01700":
                return POS_CASH_ADVANCE;
            case "18736":
                return POS_PRE_AUTH;
            case "19737":
                return POS_COMPLETION;
            default:
                return "";
        }
    }

    private static String extractLeftPartOfIsoMessage(String line) {
        Pattern pattern = Pattern.compile("^([0-9A-Fa-f.]+)\\s+");
        Matcher matcher = pattern.matcher(line);

        if (matcher.find()) {
            return matcher.group(1);
        }

        return "";
    }


    /*  ----------------------------------------------------------------
        ---------------------- DECODE FUNCTIONS ------------------------
        ---------------------------------------------------------------- */

    private static String hexToAscii(String hexString) {
        StringBuilder output = new StringBuilder();

        for (int i = 0; i < hexString.length(); i += 2) {
            String hex = hexString.substring(i, i + 2);
            int decimal = Integer.parseInt(hex, 16);
            output.append((char) decimal);
        }

        return output.toString();
    }

    public static String hexToBinary(String hexString) {
        StringBuilder binaryStringBuilder = new StringBuilder();

        for (int i = 0; i < hexString.length(); i++) {
            char hexChar = hexString.charAt(i);
            int decimalValue = Character.digit(hexChar, 16);
            String binaryValue = Integer.toBinaryString(decimalValue);

            // Ensure leading zeros for each nibble
            while (binaryValue.length() < 4) {
                binaryValue = "0" + binaryValue;
            }

            binaryStringBuilder.append(binaryValue);
        }

        return binaryStringBuilder.toString();
    }


    /*  ----------------------------------------------------------------
        --------- ISO MESSAGE FIELD DECODE HELPER FUNCTIONS ------------
        ---------------------------------------------------------------- */

    private int handleLengthDefinedField(Iso8583FieldDto fieldDto, Iso8583ConfigurationField configElement, String isoMessage, int dataIndex) {
        // Set Length As per Conf
        fieldDto.setLength(configElement.getLength());

        // Set StartAt and EndAt
        int startAt = dataIndex;
        int endAt = startAt + (configElement.getLength() * getMultiplierValueFromMech(configElement.getEncodeMech()));

        // Get Encoded Message and Decode the message. Set the message to the field dto
        fieldDto.setEncodedMessage(isoMessage.substring(startAt, endAt));
        fieldDto.setDecodedMessage(hexToAscii(isoMessage.substring(startAt, endAt)));

        // updating the data index to end of field
        return endAt;
    }

    private int handleDynamicLengthField(Iso8583FieldDto fieldDto, Iso8583ConfigurationField configElement, String isoMessage, int dataIndex) {
        // Set the Format As per Conf
        String format = configElement.getFormat();
        fieldDto.setFormat(format);

        // Get the length of the field based on the length encoded
        int fieldLengthCharacterSize = getConstantValue(format) * 2;

        // Set Starting and Ending index for encoded length
        int startAt = dataIndex;
        int endAt = startAt + fieldLengthCharacterSize;

        // Get the length and set it to the field dto
        int fieldLength = Integer.parseInt(hexToAscii(isoMessage.substring(startAt, endAt)));
        fieldDto.setLength(fieldLength);

        // Retreiving the Field Data based on the decoded length
        dataIndex = endAt; // shift the index after calculating the length
        startAt = dataIndex;
        endAt = startAt + (fieldLength * 2);

        String encodedMessage = isoMessage.substring(startAt, endAt);

        // Get Encoded Message and Decode the message. Set the message to the field dto
        fieldDto.setEncodedMessage(encodedMessage);
        fieldDto.setDecodedMessage(hexToAscii(isoMessage.substring(startAt, endAt)));

        if (configElement.isNestedField()) {
            fieldDto.setIsNestedField(true);
            handleNestedField(encodedMessage, fieldDto, configElement);
        }


        // updating the data index to end of field
        return endAt;
    }

    private void handleNestedField(String fieldMessage, Iso8583FieldDto fieldDto, Iso8583ConfigurationField configElement) {
        Map<Integer, Iso8583NestedFieldDto> nestedField = new HashMap<>();
        Integer tagIdSize = getMultiplierValueFromMech(configElement.getEncodeMech()) * getConstantValue(configElement.getNested() + "_NESTED_MESSAGE_ID_SIZE");
        Integer tagLengthSize = getMultiplierValueFromMech(configElement.getEncodeMech()) * getConstantValue(configElement.getNested() + "_NESTED_MESSAGE_LENGTH_SIZE");
        for (Integer fieldMessageIndex = 0; fieldMessageIndex < fieldMessage.length(); ) {
            Iso8583NestedFieldDto nestedFieldDto = new Iso8583NestedFieldDto();

            // Set Encode Mechanism
            nestedFieldDto.setEncodeMech(getBswitchEncodeMech());

            // get Tag Id
            Integer startAt = fieldMessageIndex;
            Integer endAt = startAt + tagIdSize;
            Integer tagId = Integer.parseInt(hexToAscii(fieldMessage.substring(startAt, endAt)));
            nestedFieldDto.setFieldId(tagId);

            // get Tag Length
            startAt = endAt;
            endAt = startAt + tagLengthSize;
            Integer tagLength = Integer.parseInt(hexToAscii(fieldMessage.substring(startAt, endAt)));
            nestedFieldDto.setLength(tagLength);

            // Get Encoded Message and Decode it
            startAt = endAt;
            endAt = startAt + getMultiplierValueFromMech(getBswitchEncodeMech()) * tagLength;
            String encodedNestedMessage = fieldMessage.substring(startAt, endAt);
            String decodedNestedMessage = hexToAscii(encodedNestedMessage);

            // Set the message to the Nested Field dto
            nestedFieldDto.setEncodedMessage(encodedNestedMessage);
            nestedFieldDto.setDecodedMessage(decodedNestedMessage);

            nestedField.put(tagId, nestedFieldDto);
            fieldMessageIndex = endAt;
        }

        fieldDto.setNestedField(nestedField);
    }

    /*  ----------------------------------------------------------------
        ------------------ FIELD CONFIG FUNCTIONS ----------------------
        ---------------------------------------------------------------- */

    public Map<String, Iso8583ConfigurationField> mapIsoConfigField(String MTI, String templateType) {
        Map<String, Map<String, Iso8583ConfigurationField>> configMap = iso8583ConfigurationReader.getConfigMap(MTI, templateType);
        Map<String, Iso8583ConfigurationField> fieldMap = configMap.get(MTI);
        if (fieldMap != null) {
            return fieldMap;
        } else {
            throw new RuntimeException("Configuration not Fond for MTI " + MTI + " - Template Type " + templateType);
        }
    }

    /*  ----------------------------------------------------------------
        -------------- ISO MESSAGE FORMATTER FUNCTIONS -----------------
        ---------------------------------------------------------------- */

    public String[] extractActualMessage(String isoMessage) {
        String[] messageLines = isoMessage.split("\\r?\\n");
        List<String> extractedMessageList = new ArrayList<>();

        // Remove Right side unwanted texts in the message
        for (String messageLine : messageLines) {
            String leftPart = extractLeftPartOfIsoMessage(messageLine);
            extractedMessageList.add(leftPart);
        }

        String[] extractedMessage = extractedMessageList.toArray(new String[0]);

        for (int i = 0; i < extractedMessage.length; i++) {
            // Remove dots from each line
            extractedMessage[i] = extractedMessage[i].replaceAll("\\.", "");
        }

        return extractedMessage;
    }

    /*  ----------------------------------------------------------------
        -------------- ISO MESSAGE PROCESSOR FUNCTIONS -----------------
        ---------------------------------------------------------------- */

    public String getMTI(String isoMessage, String encodeMech) {
        String hexEncodedMTI = isoMessage.substring(0, Math.min(isoMessage.length(), getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE")));
        String asciiDecodedMTI = hexToAscii(hexEncodedMTI);
        return asciiDecodedMTI;
    }

    public String getPrimaryBitmap(String isoMessage, String encodeMech) {
        if (isoMessage.length() < getMultiplierValueFromMech(encodeMech) * getConstantValue("PRIMARY_BITMAP_SIZE")) {
            throw new RuntimeException("Invalid ISO message format. Message is too short.");
        }

        String hexEncodedPrimaryBitmap = isoMessage.substring(
                getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE"),
                getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE") + getMultiplierValueFromMech(encodeMech) * getConstantValue("PRIMARY_BITMAP_SIZE")
        );
        String binaryDecodedPrimaryBitmap = hexToBinary(hexEncodedPrimaryBitmap);
        return binaryDecodedPrimaryBitmap;
    }

    public String getFullBitmap(String isoMessage, String encodeMech) {
        String primaryBitmap = getPrimaryBitmap(isoMessage, encodeMech);
        if (primaryBitmap.charAt(0) == '0') {
            return primaryBitmap;
        } else {
            String hexEncodeMessage = isoMessage.substring(
                    getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE") + getMultiplierValueFromMech(encodeMech) * getConstantValue("PRIMARY_BITMAP_SIZE"),
                    getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE") + getMultiplierValueFromMech(encodeMech) * getConstantValue("PRIMARY_BITMAP_SIZE") + getMultiplierValueFromMech(encodeMech) * getConstantValue("SECONDARY_BITMAP_SIZE"));
            String secondaryBitmap = hexToBinary(hexEncodeMessage);
            return primaryBitmap + secondaryBitmap;
        }
    }

    /*  ----------------------------------------------------------------
        ------------- ISO MESSAGE FIELD DECODE FUNCTIONS ---------------
        ---------------------------------------------------------------- */
    public Map<Integer, Iso8583FieldDto> getAllFieldData(String isoMessage, Iso8583Util iso8583Util) {
        // Generate Data Index
        Integer dataIndex = getMultiplierValueFromMech(getBswitchEncodeMech()) * getConstantValue("MTI_SIZE") + getMultiplierValueFromMech(getBswitchEncodeMech()) * getConstantValue("PRIMARY_BITMAP_SIZE") + getMultiplierValueFromMech(getBswitchEncodeMech()) * getConstantValue("SECONDARY_BITMAP_SIZE");

        // Get MTI and BitMap from Iso Message
        String MTI = getMTI(isoMessage, getBswitchEncodeMech());
        String bitmap = getFullBitmap(isoMessage, getBswitchEncodeMech());

        // Generate Iso Field Conf from the MTI
        Map<String, Iso8583ConfigurationField> fieldMap = iso8583Util.mapIsoConfigField(MTI, "parse");

        // Initialize Field List
        Map<Integer, Iso8583FieldDto> fieldList = new HashMap<>();

        for (Integer dataFieldIndex = 1; dataFieldIndex < bitmap.length(); dataFieldIndex++) {
            // Initiate Index
            String fieldIndex = String.valueOf(dataFieldIndex + 1);
            if (bitmap.charAt(dataFieldIndex) == '1') {
                if (fieldMap.containsKey(fieldIndex)) {
                    // initiate the field dto
                    Iso8583FieldDto fieldDto = new Iso8583FieldDto();

                    // get Field configuration for field map
                    Iso8583ConfigurationField configElement = fieldMap.get(fieldIndex);

                    // set configuration data to dto
                    fieldDto.setFieldId(Integer.parseInt(fieldIndex));
                    fieldDto.setDataType(configElement.getDataType());
                    fieldDto.setEncodeMech(configElement.getEncodeMech());
                    if (configElement.isLengthDefinition()) {
                        dataIndex = handleLengthDefinedField(fieldDto, configElement, isoMessage, dataIndex);
                    } else {
                        dataIndex = handleDynamicLengthField(fieldDto, configElement, isoMessage, dataIndex);
                    }
                    fieldList.put(Integer.parseInt(fieldIndex), fieldDto);
                } else {
                    System.out.println("Field Conf Missing for FIELD " + fieldIndex);
                }
            }
        }
        return fieldList;
    }


    /*  ----------------------------------------------------------------
        ------------- B SWITCH DATA PROCESSING FUNCTIONS ---------------
        ---------------------------------------------------------------- */

    private String generateBalanceEnquiryTemplate(Iso8583MessageDto isoMessage, String transactionType) {
        BalanceRequestTemplate balanceEnquiryXml = new BalanceRequestTemplate();
        StringWriter responseBody = new StringWriter();

        // get machine code
        String machineType = getMachineCode(transactionType);

        // get field 37, 2
        Iso8583FieldDto field37 = isoMessage.getFieldList().get(37);
        Iso8583FieldDto field2  = isoMessage.getFieldList().get(2);

        // set data to the template
        balanceEnquiryXml.setBank("fenacobu");
        balanceEnquiryXml.setExternaltransactionid(field37.getDecodedMessage());
        balanceEnquiryXml.setMachinetype(machineType);
        balanceEnquiryXml.setAtm_card_no(field2.getDecodedMessage());

        try {
            JAXBContext context = JAXBContext.newInstance(BalanceRequestTemplate.class);

            Marshaller marshaller = context.createMarshaller();


            marshaller.marshal(balanceEnquiryXml, responseBody);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return responseBody.toString();
    }


    private String generateWithdrawTemplate(Iso8583MessageDto isoMessage, String transactionType) {
        WithdrawRequestTemplate withdrawXml = new WithdrawRequestTemplate();
        StringWriter responseBody = new StringWriter();

        // get machine code
        String machineType = getMachineCode(transactionType);

        // get field 2, 37, 5, 50, 48 - tag 2, 42
        Iso8583FieldDto field2  = isoMessage.getFieldList().get(2);
        Iso8583FieldDto field37 = isoMessage.getFieldList().get(37);
        Iso8583FieldDto field5  = isoMessage.getFieldList().get(5);
        Iso8583FieldDto field50  = isoMessage.getFieldList().get(50);
        Iso8583FieldDto field42  = isoMessage.getFieldList().get(42);
        Iso8583NestedFieldDto field48Tag2  = isoMessage.getFieldList().get(48).getNestedField().get(2);

        // set data to the template
        withdrawXml.setBank("fenacobu");
        withdrawXml.setExternaltransactionid(field37.getDecodedMessage());
        withdrawXml.setMachinetype(machineType);
        withdrawXml.setAtm_card_no(field2.getDecodedMessage());
        withdrawXml.setAmount(field5.getDecodedMessage());
        withdrawXml.setInstitutionid(field48Tag2.getDecodedMessage());
        withdrawXml.setCurrency(field50.getDecodedMessage());
        withdrawXml.setTransaction_type(getTransactionType(transactionType));
        withdrawXml.setMerchantid(field42.getDecodedMessage());


        try {
            JAXBContext context = JAXBContext.newInstance(WithdrawRequestTemplate.class);

            Marshaller marshaller = context.createMarshaller();


            marshaller.marshal(withdrawXml, responseBody);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return responseBody.toString();
    }

    public String getRequestXml(Iso8583MessageDto isoMessage) {
        Map<Integer, Iso8583FieldDto> fieldList = isoMessage.getFieldList();

        // Get Field 3 and Field 48
        Iso8583FieldDto field3 = fieldList.get(3);
        Iso8583FieldDto field48 = fieldList.get(48);

        // Transaction type = first 2 character of field 3 and Tag 2 from field 48
        String transactionType = field3.getDecodedMessage().substring(0,2) + field48.getNestedField().get(2).getDecodedMessage();

        // Get Template based on the transaction type

        // Set Machine Type using transaction type
        String machineType = getMachineCode(transactionType);

        switch (transactionType) {
            case "31702":
                return generateBalanceEnquiryTemplate(isoMessage, transactionType);
            default:
                return generateWithdrawTemplate(isoMessage, transactionType);
        }
    }
}