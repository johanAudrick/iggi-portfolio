package com.fenacobu.VGateway.controller;

import com.fenacobu.VGateway.dto.iso8583xmltemplate.BalanceRequestTemplate;
import com.fenacobu.VGateway.dto.mock.MockXml;
import com.fenacobu.VGateway.service.Iso8583Service;
import com.fenacobu.VGateway.util.Iso8583Util;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.StringWriter;

@RestController
@RequestMapping("/api/v1")
@AllArgsConstructor
public class MockController {
    private final Iso8583Service iso8583Service;

    @GetMapping("/getConfig")
    public ResponseEntity<String> getConfigMethod() {
        iso8583Service.processConfig();
        return ResponseEntity.ok("Config Processed");
    }

    @PostMapping("/acquirer/request")
    public ResponseEntity<String> isoMessageincoming(@RequestBody String isoMessage) {
        return ResponseEntity.ok(iso8583Service.extractMessage(isoMessage));
    }

    @GetMapping("/mock/xml")
    public ResponseEntity<String> mockXml() {
        BalanceRequestTemplate atmBalanceRequestTemplate = new BalanceRequestTemplate();
        atmBalanceRequestTemplate.setBank("fenacobu");
        atmBalanceRequestTemplate.setAtm_card_no("xxx111xxx00");
        atmBalanceRequestTemplate.setExternaltransactionid("xxx111");
        atmBalanceRequestTemplate.setMachinetype("POS");

        try {

            StringWriter responseBody = new StringWriter();
            JAXBContext context = JAXBContext.newInstance(BalanceRequestTemplate.class);

            Marshaller marshaller = context.createMarshaller();


            marshaller.marshal(atmBalanceRequestTemplate, responseBody);

            return ResponseEntity.status(HttpStatus.ACCEPTED).header("Content-Type", "application/xml").body(responseBody.toString());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error while converting xml");
        }
    }
}
