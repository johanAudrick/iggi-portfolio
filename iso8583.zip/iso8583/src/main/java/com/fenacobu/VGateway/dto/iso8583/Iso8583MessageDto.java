package com.fenacobu.VGateway.dto.iso8583;

import com.fenacobu.VGateway.util.Iso8583Util;
import lombok.Data;

import java.util.Map;

@Data
public class Iso8583MessageDto {
    private String originalMessage;
    private String message;
    private String mti;
    private String primaryBitmap;
    private String bitmap;
    private Map<Integer, Iso8583FieldDto> fieldList;

    public Iso8583MessageDto(String isoMessage, Iso8583Util iso8583Util) {
        this.originalMessage = isoMessage;
        String extractedMessage = String.join("",iso8583Util.extractActualMessage(isoMessage));
        this.message = extractedMessage;
        this.mti = iso8583Util.getMTI(extractedMessage, iso8583Util.getBswitchEncodeMech());
        this.primaryBitmap = iso8583Util.getPrimaryBitmap(extractedMessage, iso8583Util.getBswitchEncodeMech());
        this.bitmap = iso8583Util.getFullBitmap(extractedMessage, iso8583Util.getBswitchEncodeMech());
        this.fieldList = iso8583Util.getAllFieldData(extractedMessage, iso8583Util);
    }
}
