package com.fenacobu.VGateway.service;

import com.fenacobu.VGateway.config.Iso8583ConfigurationField;
import com.fenacobu.VGateway.config.Iso8583ConfigurationReader;
import com.fenacobu.VGateway.dto.iso8583.Iso8583MessageDto;
import com.fenacobu.VGateway.dto.mock.MockDto;
import com.fenacobu.VGateway.util.Iso8583Util;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@AllArgsConstructor
public class Iso8583Service {
    private final Iso8583ConfigurationReader iso8583ConfigurationReader;
    private final Iso8583Util iso8583Util;

    public void processConfig(){
        Map<String, Map<String, Iso8583ConfigurationField>> configMap = iso8583ConfigurationReader.getConfigMap("1100", "parse");
        Map<String, Iso8583ConfigurationField> fieldMap = configMap.get("1100");

        if (fieldMap != null) {
            for (Map.Entry<String, Iso8583ConfigurationField> entry : fieldMap.entrySet()) {
                Iso8583ConfigurationField configElement = entry.getValue();

                System.out.println("Field Number: " + configElement.getId());
                System.out.println("  Data Type: " + configElement.getDataType());
                System.out.println("  Length Defined: " + configElement.isLengthDefinition());
                System.out.println("  Length: " + configElement.getLength());
            }
        } else {
            System.out.println("Configuration not found for field '1100'");
        }
    }

    public String extractMessage(String isoMessage) {
        Iso8583MessageDto isoMessageDto = new Iso8583MessageDto(isoMessage, iso8583Util);
        return isoMessageDto.getFieldList().toString();
    }
}
