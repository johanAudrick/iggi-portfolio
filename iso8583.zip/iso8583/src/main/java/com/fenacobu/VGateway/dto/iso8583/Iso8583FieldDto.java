package com.fenacobu.VGateway.dto.iso8583;

import lombok.Data;

import java.util.Map;

@Data
public class Iso8583FieldDto {
    private Integer fieldId;
    private Integer length;
    private String  encodeMech;
    private String  dataType;
    private String  format;
    private String encodedMessage;
    private String decodedMessage;
    private Boolean isNestedField;
    private Map<Integer, Iso8583NestedFieldDto> nestedField;
}
