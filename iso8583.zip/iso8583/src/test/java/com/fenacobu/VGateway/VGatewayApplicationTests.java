package com.fenacobu.VGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
