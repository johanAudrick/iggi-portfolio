package com.ad.bridge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BridgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
