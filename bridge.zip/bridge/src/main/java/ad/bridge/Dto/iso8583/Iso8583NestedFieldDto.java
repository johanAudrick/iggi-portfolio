package ad.bridge.Dto.iso8583;

import lombok.Data;

@Data
public class Iso8583NestedFieldDto {
    private Integer fieldId;
    private Integer length;
    private String  encodeMech;
    private String encodedMessage;
    private String decodedMessage;
}
