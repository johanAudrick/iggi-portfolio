    package ad.bridge.Dto.iso8583;

    import ad.bridge.Util.Iso8583Util;
    import lombok.AllArgsConstructor;
    import lombok.Data;

    import java.util.Map;

    @Data
    @AllArgsConstructor
    public class Iso8583MessageDto {
        private String originalMessage;
        private String message;
        private String mti;
        private String mtiEncode;
        private String primaryBitmap;
        private String primaryBitmapEncoded;
        private String bitmap;
        private String bitmapEncoded;
        private Map<Integer, Iso8583FieldDto> fieldList;

        public Iso8583MessageDto() {
        }
    }
