package ad.bridge.Dto.iso8583;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Map;

@Data
@AllArgsConstructor
public class Iso8583FieldDto {
    private Integer fieldId;
    private Integer length;
    private String  encodeMech;
    private String  dataType;
    private String  format;
    private String encodedMessage;
    private String decodedMessage;
    private Boolean isNestedField;
    private Map<Integer, Iso8583NestedFieldDto> nestedField;

    public Iso8583FieldDto() {
    }
}
