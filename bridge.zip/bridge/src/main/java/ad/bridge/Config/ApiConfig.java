package ad.bridge.Config;

import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@NoArgsConstructor
@Getter
public class ApiConfig {
    @Value("${api.url}")
    private String apiUrl;

    @Value("${api.username}")
    private String apiUser;

    @Value("${api.password}")
    private String apiPassword;

    @Value("${api.bswitch.endpoints.prefix}")
    private String apiUrlPrefix;

    @Value("${api.bswitch.endpoints.balance}")
    private String balanceEnquiryEndpoint;

    @Value("${api.bswitch.endpoints.ministatement}")
    private String ministatementEndpoint;


    @Value("${api.bswitch.endpoints.withdraw}")
    private String withdrawEndpoint;

    @Value("${api.bswitch.endpoints.reversal}")
    private String reversalEndpoint;
}
