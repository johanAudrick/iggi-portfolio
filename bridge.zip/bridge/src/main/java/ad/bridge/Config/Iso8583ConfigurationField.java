package ad.bridge.Config;

import lombok.Getter;

@Getter
public class Iso8583ConfigurationField {
    private final Integer id;
    private final String dataType;
    private final String encodeMech;
    private final String format;
    private final boolean nestedField;
    private final String nested;
    private final Integer length;
    private final boolean lengthDefinition;

    public Iso8583ConfigurationField(Integer id, String dataType, String encodeMech, String format, String nested, String length, boolean lengthDefinition, boolean nestedField) {

        if (dataType == null || length == null || dataType.isEmpty()) {
            throw new IllegalArgumentException("dataType and length cannot be null or empty");
        }

        Integer lengthInt = null;

        try {
            lengthInt = Integer.parseInt(length);
            if (lengthInt < 0) {
                throw new IllegalArgumentException("length must be a positive integer");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Error parsing 'length' as an integer", e);
        }
        this.id = id;
        this.dataType = dataType;
        this.encodeMech = encodeMech;
        this.format = format;
        this.nested = nested;
        this.lengthDefinition = lengthDefinition;
        this.nestedField = nestedField;
        this.length = (lengthInt != null && lengthInt > 0) ? lengthInt : null;
    }
}
