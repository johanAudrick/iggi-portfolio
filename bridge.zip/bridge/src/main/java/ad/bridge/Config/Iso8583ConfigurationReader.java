package ad.bridge.Config;

import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Component
public class Iso8583ConfigurationReader {
    private final Map<String, Map<Integer, Iso8583ConfigurationField>> configMap = new HashMap<>();

    public Iso8583ConfigurationReader() {
    }

    private void loadConfig(String messageType) {
        String messageTypeUnchanged = messageType;
        messageType = convertMessageType(messageType);
        try {
            // Getting the file and loading it as Document. Then normalizing the document
            InputStream iso8583InputStream = getClass().getClassLoader().getResourceAsStream("iso8583Conf/iso8583.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document iso8583ConfDoc = dBuilder.parse(iso8583InputStream);
            iso8583ConfDoc.getDocumentElement().normalize();

            NodeList templateList = iso8583ConfDoc.getElementsByTagName("isoMessageTemplate").item(0).getChildNodes();

            // Loop through the nodes of the template
            for (int i = 0; i< templateList.getLength(); i++) {

                // Check if the node is an Element
                if(templateList.item(i) instanceof Element) {
                    Element templateElement = (Element) templateList.item(i);

                    // Check if the node attribute "type" is same as the requested message type
                    if(templateElement.getAttribute("type").equals(messageType)) {
                        Map<Integer, Iso8583ConfigurationField> fieldMap = new HashMap<>();

                        // Get all the elements with tag name "field"
                        NodeList fieldList = templateElement.getElementsByTagName("field");

                        // Loop through the nodes of element with tag name "fields"
                        for(int j = 0; j < fieldList.getLength(); j++) {

                            // Check if the node is an Element
                            if(fieldList.item(j) instanceof Element) {
                                Element field = (Element) fieldList.item(j);

                                // get All data from the tag
                                String dataType = field.getAttribute("dataType");
                                String encodeMech = field.getAttribute("encodeMech");
                                Integer id = Integer.parseInt(field.getAttribute("id"));
                                String fieldLength = "0";
                                boolean lengthDefinition = false;
                                boolean nestedField = false;
                                String format = null;
                                String nested = null;
                                if(field.hasAttribute("length")) {
                                    fieldLength = field.getAttribute("length");
                                    lengthDefinition = true;
                                } else {
                                    format = field.getAttribute("format");
                                }
                                if(field.hasAttribute("nested")) {
                                    nested = field.getAttribute("nested");
                                    nestedField = true;
                                }

                                // Create node from the values from tag
                                Iso8583ConfigurationField fieldConf = new Iso8583ConfigurationField(id, dataType, encodeMech, format, nested, fieldLength, lengthDefinition, nestedField);
                                fieldMap.put(id, fieldConf);
                            }
                        }
                        configMap.put(messageTypeUnchanged, fieldMap);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String convertMessageType(String messageType) {
        if (messageType != null && messageType.length() >= 2) {
            String firstCharacter = messageType.substring(0, 1);
            String convertedMessageType = firstCharacter + "x" + messageType.substring(1);
            return convertedMessageType;
        } else {
            return messageType;
        }
    }

    public Map<String, Map<Integer, Iso8583ConfigurationField>> getConfigMap(String messageType) {
        loadConfig(messageType);
        return configMap;
    }
}
