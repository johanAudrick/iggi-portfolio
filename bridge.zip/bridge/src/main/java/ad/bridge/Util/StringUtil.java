package ad.bridge.Util;

import org.springframework.stereotype.Component;

@Component
public class StringUtil {
    public static byte[] binaryStringToByteArray(String binaryString) {
        int len = binaryString.length();
        byte[] data = new byte[len / 8];
        for (int i = 0; i < len; i += 8) {
            String byteString = binaryString.substring(i, i + 8);
            data[i / 8] = (byte) Integer.parseInt(byteString, 2);
        }
        return data;
    }
}
