package ad.bridge.Util;

import java.net.URI;
import java.net.URISyntaxException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class GeneralUtil {
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final SecureRandom secureRandom = new SecureRandom();

    private static final String SOCKET_HOST = "10.2.200.12";

    private static final String SOCKET_PORT = "9101";

    private static final String SOCKET_ENDPOINT = "/websocket";

    private static final AtomicInteger counter = new AtomicInteger(0);

    public static String generateUniqueId() {
        // Get current timestamp in milliseconds
        long timestamp = System.currentTimeMillis();

        // Extract the last 6 digits of the timestamp
        int lastSixDigits = (int) (timestamp % 1_000_000);

        // Increment the counter to ensure uniqueness within the same millisecond
        int uniqueCounterValue = counter.getAndIncrement() % 1_000;

        // Combine the last 6 digits of timestamp with the unique counter
        int result = lastSixDigits * 1_000 + uniqueCounterValue;

        // Ensure the result has exactly six digits by padding with leading zeros or truncating
        String resultString = String.valueOf(result);
        return resultString.length() >= 6 ? resultString.substring(0, 6) : resultString;
    }

    public static String generateTimestamp() {
        // Get the current timestamp
        Date currentTime = new Date(System.currentTimeMillis());

        // Define the desired format (YYMMDDhhmmss)
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");

        // Format the timestamp to the desired string representation
        return dateFormat.format(currentTime);
    }
}
