package ad.bridge.Util;

import ad.bridge.Config.Iso8583ConfigurationReader;
import ad.bridge.Config.Iso8583ConfigurationField;
import ad.bridge.Dto.iso8583.Iso8583FieldDto;
import ad.bridge.Dto.iso8583.Iso8583MessageDto;
import ad.bridge.Dto.iso8583.Iso8583NestedFieldDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
@AllArgsConstructor
public class Iso8583Util {

    /*  ----------------------------------------------------------------
        ------------------------- CONSTANTS ----------------------------
        ---------------------------------------------------------------- */

    private final Iso8583ConfigurationReader iso8583ConfigurationReader;

    //  MESSAGE TRANSISTION TYPE    //
    private final String SIGNON_REQUEST_CODE = "1804";

    //  FUNCTION CODES //

    private final String SIGN_ON = "801";
    private final String SIGN_OFF = "802";
    private final String ECHO_TEST = "831";
    private final String SAF_LIST_END = "841";

    private final String BASE_BITMAP = "0000000000000000000000000000000000000000000000000000000000000000";

    //  FIELD LENGTH CONSTANTS   //


    private final Integer LLVAR = 2;
    private final Integer LLLVAR = 3;
    private final Integer MTI_SIZE = 4;
    private final Integer PRIMARY_BITMAP_SIZE = 8;
    private final Integer SECONDARY_BITMAP_SIZE = 8;
    private final Integer GENERAL_NESTED_MESSAGE_ID_SIZE = 3;
    private final Integer GENERAL_NESTED_MESSAGE_LENGTH_SIZE = 3;

    //  BI SWITCH CONSTANTS //

    private final String BSWITCH_ENCODE_MECH = "HEX";
    private final String BSWITCH_BANK_NAME = "fenacobu";


    /*  ----------------------------------------------------------------
        ---------------------- HELPER FUNCTIONS ------------------------
        ---------------------------------------------------------------- */


    public Integer getConstantValue(String format) {
        switch (format) {
            case "LLVAR":
                return LLVAR;
            case "LLLVAR":
                return LLLVAR;
            case "MTI_SIZE":
                return MTI_SIZE;
            case "PRIMARY_BITMAP_SIZE":
                return PRIMARY_BITMAP_SIZE;
            case "SECONDARY_BITMAP_SIZE":
                return SECONDARY_BITMAP_SIZE;
            case "GENERAL_NESTED_MESSAGE_ID_SIZE":
                return GENERAL_NESTED_MESSAGE_ID_SIZE;
            case "GENERAL_NESTED_MESSAGE_LENGTH_SIZE":
                return GENERAL_NESTED_MESSAGE_LENGTH_SIZE;
            default:
                return LLVAR;
        }
    }

    public String getFunctionCode(String functionCodeName) {
        switch (functionCodeName) {
            case "ECHO_TEST":
                return ECHO_TEST;
            case "SIGN_ON":
                return SIGN_ON;
            case "SIGN_OFF":
                return SIGN_OFF;
            case "SAF_LIST_END":
                return SAF_LIST_END;
            default:
                return ECHO_TEST;
        }
    }

    public String getSignonRequestCode() { //
        return SIGNON_REQUEST_CODE;
    }

    private Integer getMultiplierValueFromMech(String encodeMech) {
        switch (encodeMech) {
            case "HEX":
                return 2;
            default:
                return 1;
        }
    }

    public String getBswitchEncodeMech() {
        return BSWITCH_ENCODE_MECH;
    }

    /*  ----------------------------------------------------------------
        ---------------------- DECODE FUNCTIONS ------------------------
        ---------------------------------------------------------------- */

    private static String hexToAscii(String hexString) {
        StringBuilder output = new StringBuilder();

        for (int i = 0; i < hexString.length(); i += 2) {
            String hex = hexString.substring(i, i + 2);
            int decimal = Integer.parseInt(hex, 16);
            output.append((char) decimal);
        }

        return output.toString();
    }

    public static String hexToBinary(String hexString) {
        StringBuilder binaryStringBuilder = new StringBuilder();

        for (int i = 0; i < hexString.length(); i++) {
            char hexChar = hexString.charAt(i);
            int decimalValue = Character.digit(hexChar, 16);
            String binaryValue = Integer.toBinaryString(decimalValue);

            // Ensure leading zeros for each nibble
            while (binaryValue.length() < 4) {
                binaryValue = "0" + binaryValue;
            }

            binaryStringBuilder.append(binaryValue);
        }

        return binaryStringBuilder.toString();
    }

    /*  ----------------------------------------------------------------
        ------------------ FIELD CONFIG FUNCTIONS ----------------------
        ---------------------------------------------------------------- */

    public Map<Integer, Iso8583ConfigurationField> mapIsoConfigField(String MTI, String templateType) {
        Map<String, Map<Integer, Iso8583ConfigurationField>> configMap = iso8583ConfigurationReader.getConfigMap(MTI, templateType);
        Map<Integer, Iso8583ConfigurationField> fieldMap = configMap.get(MTI);
        if (fieldMap != null) {
            return fieldMap;
        } else {
            throw new RuntimeException("Configuration not Fond for MTI " + MTI + " - Template Type " + templateType);
        }
    }

    /*  ----------------------------------------------------------------
        -------------- ISO MESSAGE PROCESSOR FUNCTIONS -----------------
        ---------------------------------------------------------------- */

    public String getMTI(String isoMessage, String encodeMech) {
        String hexEncodedMTI = isoMessage.substring(0, Math.min(isoMessage.length(), getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE")));
        String asciiDecodedMTI = hexToAscii(hexEncodedMTI);
        return asciiDecodedMTI;
    }

    public String getPrimaryBitmap(String isoMessage, String encodeMech) {
        if (isoMessage.length() < getMultiplierValueFromMech(encodeMech) * getConstantValue("PRIMARY_BITMAP_SIZE")) {
            throw new RuntimeException("Invalid ISO message format. Message is too short.");
        }

        String hexEncodedPrimaryBitmap = isoMessage.substring(
                getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE"),
                getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE") + getMultiplierValueFromMech(encodeMech) * getConstantValue("PRIMARY_BITMAP_SIZE")
        );
        String binaryDecodedPrimaryBitmap = hexToBinary(hexEncodedPrimaryBitmap);
        return binaryDecodedPrimaryBitmap;
    }

    public String getFullBitmap(String isoMessage, String encodeMech) {
        String primaryBitmap = getPrimaryBitmap(isoMessage, encodeMech);
        if (primaryBitmap.charAt(0) == '0') {
            return primaryBitmap;
        } else {
            String hexEncodeMessage = isoMessage.substring(
                    getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE") + getMultiplierValueFromMech(encodeMech) * getConstantValue("PRIMARY_BITMAP_SIZE"),
                    getMultiplierValueFromMech(encodeMech) * getConstantValue("MTI_SIZE") + getMultiplierValueFromMech(encodeMech) * getConstantValue("PRIMARY_BITMAP_SIZE") + getMultiplierValueFromMech(encodeMech) * getConstantValue("SECONDARY_BITMAP_SIZE"));
            String secondaryBitmap = hexToBinary(hexEncodeMessage);
            return primaryBitmap + secondaryBitmap;
        }
    }


    /*  ----------------------------------------------------------------
        ------------- ISO MESSAGE FIELD DECODE FUNCTIONS ---------------
        ---------------------------------------------------------------- */
    public Map<Integer, Iso8583FieldDto> getAllFieldData(String isoMessage, Iso8583Util iso8583Util) {
        // Generate Data Index
        Integer dataIndex = getMultiplierValueFromMech(getBswitchEncodeMech()) * getConstantValue("MTI_SIZE") +
                            getMultiplierValueFromMech(getBswitchEncodeMech()) * getConstantValue("PRIMARY_BITMAP_SIZE") ;

        // Get MTI and BitMap from Iso Message
        String MTI = getMTI(isoMessage, getBswitchEncodeMech());
        String bitmap = getFullBitmap(isoMessage, getBswitchEncodeMech());

        // Generate Iso Field Conf from the MTI
        Map<Integer, Iso8583ConfigurationField> fieldMap = iso8583Util.mapIsoConfigField(MTI, "parse");

        // Initialize Field List
        Map<Integer, Iso8583FieldDto> fieldList = new HashMap<>();

        for (Integer dataFieldIndex = 1; dataFieldIndex < bitmap.length(); dataFieldIndex++) {
            // Initiate Index
            String fieldIndex = String.valueOf(dataFieldIndex + 1);
            if (bitmap.charAt(dataFieldIndex) == '1') {
                if (fieldMap.containsKey(Integer.parseInt(fieldIndex))) {
                    // initiate the field dto
                    Iso8583FieldDto fieldDto = new Iso8583FieldDto();

                    // get Field configuration for field map
                    Iso8583ConfigurationField configElement = fieldMap.get(Integer.parseInt(fieldIndex));

                    // set configuration data to dto
                    fieldDto.setFieldId(Integer.parseInt(fieldIndex));
                    fieldDto.setDataType(configElement.getDataType());
                    fieldDto.setEncodeMech(configElement.getEncodeMech());
                    if (configElement.isLengthDefinition()) {
                        dataIndex = handleLengthDefinedField(fieldDto, configElement, isoMessage, dataIndex);
                    } else {
                        dataIndex = handleDynamicLengthField(fieldDto, configElement, isoMessage, dataIndex);
                    }
                    fieldList.put(Integer.parseInt(fieldIndex), fieldDto);
                } else {
                    System.out.println("Field Conf Missing for FIELD " + fieldIndex);
                }
            }
        }
        return fieldList;
    }


    /*  ----------------------------------------------------------------
        --------- ISO MESSAGE FIELD DECODE HELPER FUNCTIONS ------------
        ---------------------------------------------------------------- */

    private int handleLengthDefinedField(Iso8583FieldDto fieldDto, Iso8583ConfigurationField configElement, String isoMessage, int dataIndex) {
        // Set Length As per Conf
        fieldDto.setLength(configElement.getLength());

        // Set StartAt and EndAt
        int startAt = dataIndex;
        int endAt = startAt + (configElement.getLength() * getMultiplierValueFromMech(configElement.getEncodeMech()));

        // Get Encoded Message and Decode the message. Set the message to the field dto
        fieldDto.setEncodedMessage(isoMessage.substring(startAt, endAt));
        fieldDto.setDecodedMessage(hexToAscii(isoMessage.substring(startAt, endAt)));

        // updating the data index to end of field
        return endAt;
    }

    private int handleDynamicLengthField(Iso8583FieldDto fieldDto, Iso8583ConfigurationField configElement, String isoMessage, int dataIndex) {
        // Set the Format As per Conf
        String format = configElement.getFormat();
        fieldDto.setFormat(format);

        // Get the length of the field based on the length encoded
        int fieldLengthCharacterSize = getConstantValue(format) * 2;

        // Set Starting and Ending index for encoded length
        int startAt = dataIndex;
        int endAt = startAt + fieldLengthCharacterSize;

        // Get the length and set it to the field dto
        int fieldLength = Integer.parseInt(hexToAscii(isoMessage.substring(startAt, endAt)));
        fieldDto.setLength(fieldLength);

        // Retreiving the Field Data based on the decoded length
        dataIndex = endAt; // shift the index after calculating the length
        startAt = dataIndex;
        endAt = startAt + (fieldLength * 2);

        String encodedMessage = isoMessage.substring(startAt, endAt);

        // Get Encoded Message and Decode the message. Set the message to the field dto
        fieldDto.setEncodedMessage(encodedMessage);
        fieldDto.setDecodedMessage(hexToAscii(isoMessage.substring(startAt, endAt)));

        if (configElement.isNestedField()) {
            fieldDto.setIsNestedField(true);
            handleNestedField(encodedMessage, fieldDto, configElement);
        }


        // updating the data index to end of field
        return endAt;
    }

    private void handleNestedField(String fieldMessage, Iso8583FieldDto fieldDto, Iso8583ConfigurationField configElement) {
        Map<Integer, Iso8583NestedFieldDto> nestedField = new HashMap<>();
        Integer tagIdSize = getMultiplierValueFromMech(configElement.getEncodeMech()) * getConstantValue(configElement.getNested() + "_NESTED_MESSAGE_ID_SIZE");
        Integer tagLengthSize = getMultiplierValueFromMech(configElement.getEncodeMech()) * getConstantValue(configElement.getNested() + "_NESTED_MESSAGE_LENGTH_SIZE");
        for (Integer fieldMessageIndex = 0; fieldMessageIndex < fieldMessage.length(); ) {
            Iso8583NestedFieldDto nestedFieldDto = new Iso8583NestedFieldDto();

            // Set Encode Mechanism
            nestedFieldDto.setEncodeMech(getBswitchEncodeMech());

            // get Tag Id
            Integer startAt = fieldMessageIndex;
            Integer endAt = startAt + tagIdSize;
            Integer tagId = Integer.parseInt(hexToAscii(fieldMessage.substring(startAt, endAt)));
            nestedFieldDto.setFieldId(tagId);

            // get Tag Length
            startAt = endAt;
            endAt = startAt + tagLengthSize;
            Integer tagLength = Integer.parseInt(hexToAscii(fieldMessage.substring(startAt, endAt)));
            nestedFieldDto.setLength(tagLength);

            // Get Encoded Message and Decode it
            startAt = endAt;
            endAt = startAt + getMultiplierValueFromMech(getBswitchEncodeMech()) * tagLength;
            String encodedNestedMessage = fieldMessage.substring(startAt, endAt);
            String decodedNestedMessage = hexToAscii(encodedNestedMessage);

            // Set the message to the Nested Field dto
            nestedFieldDto.setEncodedMessage(encodedNestedMessage);
            nestedFieldDto.setDecodedMessage(decodedNestedMessage);

            nestedField.put(tagId, nestedFieldDto);
            fieldMessageIndex = endAt;
        }

        fieldDto.setNestedField(nestedField);
    }

    /*  ----------------------------------------------------------------
        -------------------- FIELD DATA FUNCTIONS ----------------------
        ---------------------------------------------------------------- */

    public void setFieldData(Iso8583MessageDto isoMessage) {
        Map<Integer, Iso8583FieldDto> fieldList = isoMessage.getFieldList();
        String systemTransactionId = GeneralUtil.generateUniqueId();
        String transactionTimeStamp = GeneralUtil.generateTimestamp();
        for (Map.Entry<Integer, Iso8583FieldDto> entry : fieldList.entrySet()) {
            Integer fieldNumber = entry.getKey();
            switch (fieldNumber) {
                case 24:
                    isoMessage.getFieldList().get(24).setDecodedMessage(this.getFunctionCode("ECHO_TEST"));
                case 11:
                    isoMessage.getFieldList().get(11).setDecodedMessage(systemTransactionId);
                case 12:
                    isoMessage.getFieldList().get(12).setDecodedMessage(transactionTimeStamp);
            }
        }
    }

    /*  ----------------------------------------------------------------
        ------------- ISO MESSAGE FIELD ENCODE FUNCTIONS ---------------
        ---------------------------------------------------------------- */

    public String generateBitmap(Iso8583MessageDto isoMessage) {
        Map<Integer, Iso8583FieldDto> fieldList = isoMessage.getFieldList();
        StringBuilder updatedBitmap = new StringBuilder(BASE_BITMAP);

        for (Map.Entry<Integer, Iso8583FieldDto> entry : fieldList.entrySet()) {
            Integer fieldNumber = entry.getKey();

            int position = fieldNumber - 1;
            if (position >= 0 && position < BASE_BITMAP.length()) {
                updatedBitmap.setCharAt(position, '1');
            } else {
                System.out.println("Invalid field number: " + fieldNumber);
            }
        }
        return updatedBitmap.toString();
    }


    public Iso8583MessageDto generateSignOnMessage() {
        Iso8583MessageDto isoMessage = new Iso8583MessageDto();
        isoMessage.setMti(getSignonRequestCode());
        Map<Integer, Iso8583FieldDto> fieldList = new HashMap<>();
        Map<Integer, Iso8583ConfigurationField> fieldConfiguration = mapIsoConfigField(isoMessage.getMti(), "create");

        for (Map.Entry<Integer, Iso8583ConfigurationField> entry : fieldConfiguration.entrySet()) {
            Integer fieldNumber = entry.getKey();
            Iso8583ConfigurationField fieldConfig = entry.getValue();

            Iso8583FieldDto fieldDto = new Iso8583FieldDto();
            fieldDto.setFieldId(fieldNumber);
            fieldDto.setLength(fieldConfig.getLength());
            fieldDto.setIsNestedField(fieldConfig.isNestedField());
            fieldDto.setEncodeMech(fieldConfig.getEncodeMech());
            fieldDto.setFormat(fieldConfig.getDataType());

            fieldList.put(fieldNumber, fieldDto);
        }

        isoMessage.setFieldList(fieldList);

        // setting field data into the fields
        setFieldData(isoMessage);

        isoMessage.setPrimaryBitmap(generateBitmap(isoMessage));

        return isoMessage;
    }

}