package ad.bridge.Handler;

import ad.bridge.Dto.iso8583.Iso8583MessageDto;
import jakarta.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class SocketHandler {

    // Session Logger
    private static final Logger sessionlog = LogManager.getLogger("sessionLogger");

    // Message Logger
    private static final Logger messagelog = LogManager.getLogger("messageLogger");

    private static final String HOST = "10.2.200.12";
    private static final int PORT = 9101;
    private HttpSession httpSession;
    private Map<String, Thread> receiverThreads;

    private final ExecutorService messageProcessorPool = Executors.newCachedThreadPool();
    private final IsoMessageHandler isoMessageHandler;

    public SocketHandler(IsoMessageHandler isoMessageHandler) {
        this.isoMessageHandler = isoMessageHandler;
        receiverThreads = new ConcurrentHashMap<>();
    }

    /*  --------------------------------------------------------------------
        ---------------------- INTIATING SOCKET ----------------------------
        --------------------------------------------------------------------    */
    public String initiateNewSession(HttpSession session) {
        sessionlog.info("INIT :: initiateNewSession");

        String sessionId = "";

        try {
            this.httpSession = session;
            sessionId = UUID.randomUUID().toString();

            sessionlog.info("SOCKET INITIATION for Host {} :: Port {}", HOST, PORT);

            Socket isoSocket = new Socket(HOST, PORT);
            session.setAttribute(sessionId, isoSocket);

            sessionlog.info("SOCKET INITIATION for Host {} :: Port {} :: Session id {} - SUCCESSFUL", HOST, PORT, sessionId);

            sessionlog.info("SOCKET MESSAGE RECEIVER INITIATION FOR {}", sessionId);

            startMessageReceiver(sessionId);

            sessionlog.info("SOCKET MESSAGE RECEIVER INITIATION FOR {} - SUCCESSFUL", sessionId);

        } catch (Exception ex) {
            sessionlog.error("EXCEPTION :: SOCKET MESSAGE RECEIVER INITIATION FOR {} - FAILURE :: {}", sessionId, ex.getMessage());
        } finally {
            sessionlog.info("END :: initiateNewSession");
            return sessionId;
        }
    }

    public Socket getSocketFromId(String sessionId) {
        return (Socket) httpSession.getAttribute(sessionId);
    }

    /*  --------------------------------------------------------------------
        ---------------- SENDING MESSAGES OVER SOCKET ----------------------
        --------------------------------------------------------------------    */

    public void sendMessage(String sessionId, byte[] message) {
        sessionlog.info("INIT :: sendMessage");

        Socket socket = getSocketFromId(sessionId);

        if (socket != null) {
            sessionlog.info("SOCKET FOUND for session id :: {}", sessionId);

            try {
                sessionlog.info("SENDING MESSAGE INITIATION for session id :: {}", sessionId);
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write(message);
                outputStream.flush(); // Flush the output stream
                sessionlog.info("SENDING MESSAGE INITIATION for session id :: {} - SUCCESSFUL", sessionId);
            } catch (IOException e) {
                sessionlog.info("EXCEPTION :: SENDING MESSAGE INITIATION for session id :: {} - FAILURE", e.getMessage());
            }
        } else {
            sessionlog.info("SOCKET NOT FOUND for session id :: {} - SUCCESSFUL", sessionId);
        }
    }

    /*  --------------------------------------------------------------------
        --------- INITIATE THREAD TO RECEIVE MESSAGES OVER SOCKET ----------
        --------------------------------------------------------------------    */

    private void startMessageReceiver(String sessionId) {
        Thread receiverThread = new Thread(() -> {
            Socket socket = getSocketFromId(sessionId);
            if (socket != null) {
                try {
                    messagelog.info("INIT :: startMessageReceiver for session id {}", sessionId);
                    InputStream inputStream = socket.getInputStream();
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        final byte[] finalBuffer = buffer.clone();
                        final int finalBytesRead = bytesRead;
                        messageProcessorPool.submit(() -> processMessage(finalBuffer, finalBytesRead, sessionId));
                    }
                    messagelog.info("END :: startMessageReceiver for session id {}", sessionId);
                } catch (IOException e) {
                    messagelog.error("EXCEPTION :: startMessageReceiver -> Error receiving message :: {}", e.getMessage());
                }
            } else {
                messagelog.error("EXCEPTION :: startMessageReceiver -> SOCKET NOT FOUND for session id {}", sessionId);
            }
        });
        receiverThreads.put(sessionId, receiverThread);
        receiverThread.start();
    }

    /*  --------------------------------------------------------------------
        ---------------------- TERMINATE SOCKET ----------------------------
        --------------------------------------------------------------------    */

    private void stopMessageReceiver(String sessionId) {
        Thread receiverThread = receiverThreads.get(sessionId);
        if (receiverThread != null && receiverThread.isAlive()) {
            receiverThread.interrupt();
            receiverThreads.remove(sessionId);
        }
    }

    public void closeSession(String sessionId) {
        sessionlog.info("INIT :: closeSession for session id {}", sessionId);

        Socket socket = getSocketFromId(sessionId);
        if (socket != null) {
            try {
                sessionlog.info("SOCKET FOUND for session id {}", sessionId);

                stopMessageReceiver(sessionId); // Stop the message receiver thread
                sessionlog.info("MESSAGE RECEIVER STOPPED for session id {}", sessionId);

                socket.close(); // Close the socket
                httpSession.removeAttribute(sessionId); // Remove socket from session
                sessionlog.info("SOCKET CLOSED for session id {}", sessionId);
            } catch (IOException e) {
                sessionlog.error("EXCEPTION :: closeSession Error closing socket :: {} ", e.getMessage());
            }
        } else {
            sessionlog.error("SOCKET NOT FOUND for session id {}", sessionId);
        }
    }

    /*  --------------------------------------------------------------------
        ----------------- PROCESS ISO 8583 MESSAGE -------------------------
        --------------------------------------------------------------------    */

    private void processMessage(byte[] buffer, int bytesRead, String sessionId) {

        messagelog.info("INIT :: processMessage for session id {}", sessionId);

        // Convert received bytes to hexadecimal string
        StringBuilder hexString = new StringBuilder();
        for (int i = 0; i < bytesRead; i++) {
            String hex = Integer.toHexString(buffer[i] & 0xFF);
            if (hex.length() == 1) {
                // Append leading zero if hex length is only 1
                hexString.append('0');
            }
            hexString.append(hex);
        }
        String receivedMessage = hexString.toString();

        messagelog.info("RECEIVED ISO MESSAGE :: {}", receivedMessage);

        Iso8583MessageDto receivedIsoMessage = isoMessageHandler.initIsoMessage(receivedMessage);

        messagelog.info("INITIATING RESPONSE FLOW FOR RECEIVED MESSAGE on Session id :: {}", sessionId);
        switch (receivedIsoMessage.getMti()) {
            case "1804":
                try {
                    sendMessage(sessionId, isoMessageHandler.generateSignonResponse(receivedIsoMessage));
                } catch (IOException e) {
                    messagelog.error("EXCEPTION :: While Sending Response for MTI {} - {}", "1804", e.getMessage());
                }
                break;
        }

        messagelog.info("END :: processMessage for session id {}", sessionId);

    }

}
