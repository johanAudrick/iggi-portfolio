package ad.bridge.Handler;

import ad.bridge.Dto.iso8583.Iso8583MessageDto;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class SocketHandler {
    private static final Logger log = LoggerFactory.getLogger(SocketHandler.class);

    //    private static final String HOST = "localhost";
    private static final String HOST = "10.2.200.12";
    private static final int PORT = 9101;
    private HttpSession httpSession;
    private Map<String, Thread> receiverThreads;

    private final ExecutorService messageProcessorPool = Executors.newCachedThreadPool();
    private final IsoMessageHandler isoMessageHandler;

    public SocketHandler(IsoMessageHandler isoMessageHandler) {
        this.isoMessageHandler = isoMessageHandler;
        receiverThreads = new ConcurrentHashMap<>();
    }

    /*  --------------------------------------------------------------------
        ---------------------- INTIATING SOCKET ----------------------------
        --------------------------------------------------------------------    */
    public String initiateNewSession(HttpSession session) {

        log.info("Initiating new socket ...");

        String sessionId = "";
        try {
            this.httpSession = session;
            sessionId = UUID.randomUUID().toString();

            Socket isoSocket = new Socket(HOST, PORT);

            session.setAttribute(sessionId, isoSocket);

            log.info("Socket Initiated :: " + sessionId);

            log.info("Initiating Message Receive ... ");
            startMessageReceiver(sessionId);
            log.info("Successful");

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            log.error("Exception :: " + ex.getMessage());
        } finally {
            return sessionId;
        }
    }

    public Socket getSocketFromId(String sessionId) {
        return (Socket) httpSession.getAttribute(sessionId);
    }

    /*  --------------------------------------------------------------------
        ---------------- SENDING MESSAGES OVER SOCKET ----------------------
        --------------------------------------------------------------------    */

    public void sendMessage(String sessionId, byte[] message) {
        Socket socket = getSocketFromId(sessionId);
        if (socket != null) {
            try {
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write(message);
                outputStream.flush(); // Flush the output stream
            } catch (IOException e) {
                System.out.println("Error sending message: " + e.getMessage());
            }
        } else {
            System.out.println("Socket is not found for session ID: " + sessionId);
        }
    }

    /*  --------------------------------------------------------------------
        --------- INITIATE THREAD TO RECEIVE MESSAGES OVER SOCKET ----------
        --------------------------------------------------------------------    */

    private void startMessageReceiver(String sessionId) {
        Thread receiverThread = new Thread(() -> {
            Socket socket = getSocketFromId(sessionId);
            if (socket != null) {
                try {
                    InputStream inputStream = socket.getInputStream();
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        final byte[] finalBuffer = buffer.clone();
                        final int finalBytesRead = bytesRead;
                        messageProcessorPool.submit(() -> processMessage(finalBuffer, finalBytesRead));
                    }
                } catch (IOException e) {
                    System.out.println("Error receiving message: " + e.getMessage());
                }
            } else {
                System.out.println("Socket is not found for session ID: " + sessionId);
            }
        });
        receiverThreads.put(sessionId, receiverThread);
        receiverThread.start();
    }

    /*  --------------------------------------------------------------------
        ---------------------- TERMINATE SOCKET ----------------------------
        --------------------------------------------------------------------    */

    private void stopMessageReceiver(String sessionId) {
        Thread receiverThread = receiverThreads.get(sessionId);
        if (receiverThread != null && receiverThread.isAlive()) {
            receiverThread.interrupt();
            receiverThreads.remove(sessionId);
        }
    }

    public void closeSession(String sessionId) {
        Socket socket = getSocketFromId(sessionId);
        if (socket != null) {
            try {
                stopMessageReceiver(sessionId); // Stop the message receiver thread
                socket.close(); // Close the socket
                httpSession.removeAttribute(sessionId); // Remove socket from session
            } catch (IOException e) {
                System.out.println("Error closing socket: " + e.getMessage());
            }
        } else {
            System.out.println("Socket is not found for session ID: " + sessionId);
        }
    }

    /*  --------------------------------------------------------------------
        ----------------- PROCESS ISO 8583 MESSAGE -------------------------
        --------------------------------------------------------------------    */

    private void processMessage(byte[] buffer, int bytesRead) {
        // Convert received bytes to hexadecimal string
        StringBuilder hexString = new StringBuilder();
        for (int i = 0; i < bytesRead; i++) {
            String hex = Integer.toHexString(buffer[i] & 0xFF);
            if (hex.length() == 1) {
                // Append leading zero if hex length is only 1
                hexString.append('0');
            }
            hexString.append(hex);
        }
        String receivedMessage = hexString.toString();

        System.out.println("Process Message :: Received message (hex): " + receivedMessage);

        Iso8583MessageDto receivedIsoMessage = isoMessageHandler.initIsoMessage(receivedMessage);

    }

}
