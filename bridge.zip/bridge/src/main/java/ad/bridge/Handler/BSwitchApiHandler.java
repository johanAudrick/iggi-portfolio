package ad.bridge.Handler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;

@Component
public class BSwitchApiHandler {
    private final String apiUrl;
    private final String username;
    private final String password;

    private final RestTemplate restTemplate;

    private Logger messagelog = LogManager.getLogger("messageLogger");

    public BSwitchApiHandler(
            @Value("${api.url}") String apiUrl,
            @Value("${api.username}") String username,
            @Value("${api.password}") String password,
            @Value("${api.bswitch.endpoints.prefix}") String apiUrlPrefix
    ) {
        this.apiUrl = apiUrl + apiUrlPrefix;
        this.username = username;
        this.password = password;
        this.restTemplate = new RestTemplate();
    }

    public ResponseEntity<String> sendGet(String endpoint) {
        String url = apiUrl + endpoint;
        HttpHeaders headers = createHeaders();
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
        messagelog.info(url);
        return restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);
    }

    public ResponseEntity<String> sendPost(String endpoint, String xmlBody) {
        messagelog.info("Initiated send Post");
        String url = apiUrl + endpoint;
        messagelog.info("Send Post URL {}", url);
        messagelog.info("Send Post Body {}", xmlBody);
        HttpHeaders headers = createHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        HttpEntity<String> requestEntity = new HttpEntity<>(xmlBody, headers);
        return restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
    }

    private HttpHeaders createHeaders() {
        return new HttpHeaders() {{
            String auth = username + ":" + password;
            byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.US_ASCII), true);
            String authHeader = "Basic " + new String(encodedAuth, StandardCharsets.US_ASCII).replaceAll("[\\n\\r]+", "");
            set("Authorization", authHeader);
        }};
    }
}
