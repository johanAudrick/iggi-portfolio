package ad.bridge.Handler;

import ad.bridge.Config.ApiConfig;
import ad.bridge.Dto.iso8583.Iso8583MessageDto;
import ad.bridge.Enum.Field39Enum;
import ad.bridge.Util.Iso8583Util;
import lombok.AllArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@AllArgsConstructor
public class IsoMessageHandler {
    private static final Logger messagelog = LogManager.getLogger("messageLogger");

    private Iso8583Util iso8583Util;
    private BSwitchApiHandler bSwitchApiHandler;
    private ApiConfig apiConfig;

    public Iso8583MessageDto initIsoMessage(String originalIsoMessage) {
        messagelog.info("INIT :: initIsoMessage");

        Iso8583MessageDto isoMessage = new Iso8583MessageDto();

        messagelog.info("ISO MESSAGE DATA :: ORIGINAL MESSAGE -> {}", originalIsoMessage);
        isoMessage.setOriginalMessage(originalIsoMessage);

        messagelog.info("ISO MESSAGE DATA :: MTI -> {}", iso8583Util.getMTI(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));
        isoMessage.setMti(iso8583Util.getMTI(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));

        messagelog.info("ISO MESSAGE DATA :: PRIMARY BITMAP -> {}", iso8583Util.getPrimaryBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));
        isoMessage.setPrimaryBitmap(iso8583Util.getPrimaryBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));

        messagelog.info("ISO MESSAGE DATA :: FULL BITMAP -> {}", iso8583Util.getFullBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));
        isoMessage.setBitmap(iso8583Util.getFullBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));


        isoMessage.setFieldList(iso8583Util.getAllFieldData(originalIsoMessage, iso8583Util));

        messagelog.info("END :: initIsoMessage");
        return isoMessage;
    }

    public byte[] generateSignonResponse(Iso8583MessageDto isoMessage) throws IOException {
        messagelog.info("INIT :: generateSignonResponse with MTI {}", iso8583Util.getSignOnResponseCode());
        Iso8583MessageDto responseIsoMessage = iso8583Util.getIsoMessage(iso8583Util.getSignOnResponseCode());

        messagelog.info("SETTING System Trace Number - {}", isoMessage.getFieldList().get(11).getDecodedMessage());
        responseIsoMessage.getFieldList().get(11).setDecodedMessage(
                isoMessage.getFieldList().get(11).getDecodedMessage()
        );

        messagelog.info("SETTING response code to {}", Field39Enum.SUCCESSFUL_TRANSACTION.getCode());
        responseIsoMessage.getFieldList().get(39).setDecodedMessage(Field39Enum.SUCCESSFUL_TRANSACTION.getCode());

        messagelog.info("END :: generateSignonResponse with MTI {}", iso8583Util.getSignOnResponseCode());
        return iso8583Util.convertIsoMessageToByte(responseIsoMessage);
    }

    public String getRequestXml(Iso8583MessageDto isoMessage) {
        // Transaction type
        String transactionType = iso8583Util.getTransactionTypeFromIsoMessage(isoMessage);

        switch (transactionType) {
            case "31702":
                return iso8583Util.generateBalanceEnquiryTemplate(isoMessage, transactionType);
            default:
                return iso8583Util.generateWithdrawTemplate(isoMessage, transactionType);
        }
    }

    public ResponseEntity<String> handleApiADF(Iso8583MessageDto isoMessage, String xmlBody) {
        // Transaction type
        String transactionType = iso8583Util.getTransactionTypeFromIsoMessage(isoMessage);

        switch (transactionType) {
            case "31702":
                return bSwitchApiHandler.sendPost(apiConfig.getBalanceEnquiryEndpoint(), xmlBody);
            case "00774", "09776", "01700":
                return bSwitchApiHandler.sendPost(apiConfig.getWithdrawEndpoint(), xmlBody);
            default:
                return null;
        }
    }
}
