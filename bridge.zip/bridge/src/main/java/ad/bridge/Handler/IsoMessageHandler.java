package ad.bridge.Handler;

import ad.bridge.Dto.iso8583.Iso8583MessageDto;
import ad.bridge.Util.Iso8583Util;
import lombok.AllArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class IsoMessageHandler {
    private static final Logger messagelog = LogManager.getLogger("messageLogger");

    private Iso8583Util iso8583Util;
    public Iso8583MessageDto initIsoMessage(String originalIsoMessage) {
        messagelog.info("INIT :: initIsoMessage");

        Iso8583MessageDto isoMessage = new Iso8583MessageDto();

        messagelog.info("ISO MESSAGE DATA :: ORIGINAL MESSAGE -> {}", originalIsoMessage);
        isoMessage.setOriginalMessage(originalIsoMessage);

        messagelog.info("ISO MESSAGE DATA :: MTI -> {}", iso8583Util.getMTI(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));
        isoMessage.setMti(iso8583Util.getMTI(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));

        messagelog.info("ISO MESSAGE DATA :: PRIMARY BITMAP -> {}", iso8583Util.getPrimaryBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));
        isoMessage.setPrimaryBitmap(iso8583Util.getPrimaryBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));

        messagelog.info("ISO MESSAGE DATA :: FULL BITMAP -> {}", iso8583Util.getFullBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));
        isoMessage.setBitmap(iso8583Util.getFullBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));


        isoMessage.setFieldList(iso8583Util.getAllFieldData(originalIsoMessage, iso8583Util));

        messagelog.info("END :: initIsoMessage");
        return isoMessage;
    }
}
