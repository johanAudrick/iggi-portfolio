package ad.bridge.Handler;

import ad.bridge.Dto.iso8583.Iso8583MessageDto;
import ad.bridge.Util.Iso8583Util;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class IsoMessageHandler {
    private Iso8583Util iso8583Util;
    public Iso8583MessageDto initIsoMessage(String originalIsoMessage) {
        Iso8583MessageDto isoMessage = new Iso8583MessageDto();

        System.out.println("SET ORIGINAL MESSAGE :: " + originalIsoMessage);
        isoMessage.setOriginalMessage(originalIsoMessage);

        System.out.println("SET ISO MTI :: " + iso8583Util.getMTI(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));
        isoMessage.setMti(iso8583Util.getMTI(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));

        System.out.println("SET PRIMARY BITMAP :: " + iso8583Util.getPrimaryBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));
        isoMessage.setPrimaryBitmap(iso8583Util.getPrimaryBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));

        System.out.println("SET FULL BITMAP :: " + iso8583Util.getFullBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));
        isoMessage.setBitmap(iso8583Util.getFullBitmap(originalIsoMessage, iso8583Util.getBswitchEncodeMech()));

        isoMessage.setFieldList(iso8583Util.getAllFieldData(originalIsoMessage, iso8583Util));

        return isoMessage;
    }
}
