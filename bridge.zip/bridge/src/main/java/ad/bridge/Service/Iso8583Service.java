package ad.bridge.Service;

import ad.bridge.Config.Iso8583ConfigurationField;
import ad.bridge.Config.Iso8583ConfigurationReader;
import ad.bridge.Dto.iso8583.Iso8583FieldDto;
import ad.bridge.Dto.iso8583.Iso8583MessageDto;
import ad.bridge.Enum.Field39Enum;
import ad.bridge.Util.Iso8583Util;
import ad.bridge.Util.StringUtil;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

@Service
@AllArgsConstructor
public class Iso8583Service {

    private final Iso8583Util iso8583Util;
    private final StringUtil stringUtil;

    public byte[] getSignonMessage() throws IOException {
        Iso8583MessageDto isoMessage = iso8583Util.getIsoMessage(iso8583Util.getSignonRequestCode());
        return iso8583Util.convertIsoMessageToByte(isoMessage);
    }
}
