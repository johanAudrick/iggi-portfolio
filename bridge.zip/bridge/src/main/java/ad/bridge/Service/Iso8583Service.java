package ad.bridge.Service;

import ad.bridge.Config.Iso8583ConfigurationField;
import ad.bridge.Config.Iso8583ConfigurationReader;
import ad.bridge.Dto.iso8583.Iso8583FieldDto;
import ad.bridge.Dto.iso8583.Iso8583MessageDto;
import ad.bridge.Util.Iso8583Util;
import ad.bridge.Util.StringUtil;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

@Service
@AllArgsConstructor
public class Iso8583Service {

    private final Iso8583Util iso8583Util;
    private final StringUtil stringUtil;

    public byte[] getSignonMessage() throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Iso8583MessageDto isoMessage = iso8583Util.generateSignOnMessage();

        Map<Integer, Iso8583FieldDto> fieldList = isoMessage.getFieldList();
        Map<Integer, Iso8583FieldDto> sortedFieldList = new TreeMap<>(fieldList);

        byteArrayOutputStream.write(isoMessage.getMti().getBytes());

        // Set Binary Bytes
        byte[] bitmap = stringUtil.binaryStringToByteArray(isoMessage.getPrimaryBitmap());
        byteArrayOutputStream.write(bitmap);

        for (Map.Entry<Integer, Iso8583FieldDto> entry : sortedFieldList.entrySet()) {
            Iso8583FieldDto fieldData = entry.getValue();
            String fieldValue = fieldData.getDecodedMessage();

            // Write field value
            byteArrayOutputStream.write(fieldValue.getBytes());
        }

        byte[] convertedIsoMessage = byteArrayOutputStream.toByteArray();

        return convertedIsoMessage;
    }
}
