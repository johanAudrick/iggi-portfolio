package ad.bridge.Service;

public class ApiService {
}
