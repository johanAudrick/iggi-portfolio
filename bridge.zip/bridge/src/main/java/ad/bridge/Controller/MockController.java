package ad.bridge.Controller;

import ad.bridge.Dto.iso8583.Iso8583MessageDto;
import ad.bridge.Handler.BSwitchApiHandler;
import ad.bridge.Handler.IsoMessageHandler;
import ad.bridge.Service.Iso8583Service;
import ad.bridge.Util.Iso8583Util;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mock")
@AllArgsConstructor
public class MockController {

    private final IsoMessageHandler isoMessageHandler;

    @GetMapping("/iso-test")
    public ResponseEntity<String> testIsoSetter(@RequestParam String isoMessage) {
        Iso8583MessageDto isoMessageDto = isoMessageHandler.initIsoMessage(isoMessage);
//        return ResponseEntity.ok(isoMessageDto.toString());
        String requestMessage = isoMessageHandler.getRequestXml(isoMessageDto);
//        return ResponseEntity.ok(requestMessage);
        return isoMessageHandler.handleApiADF(isoMessageDto, requestMessage);
    }
}
