package ad.bridge.Controller;

import ad.bridge.Handler.SocketHandler;
import ad.bridge.Service.Iso8583Service;
import jakarta.servlet.http.HttpSession;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.UnknownHostException;

@RestController
@RequestMapping("/socket")
@AllArgsConstructor
public class SocketController {

    private final SocketHandler socketHandler;

    private final Iso8583Service iso8583Service;

    @GetMapping("/connect")
    public ResponseEntity<String> connectSocket(HttpSession session) {
        String sessionId = socketHandler.initiateNewSession(session);
        if (sessionId != null && !sessionId.isEmpty()) {
            return ResponseEntity.ok("Socket connected with session ID: " + sessionId);
        } else {
            return ResponseEntity.badRequest().body("Failed to connect to the socket");
        }
    }

    @GetMapping("/close")
    public ResponseEntity<String> closeSocket(@RequestParam String sessionId) {
        socketHandler.closeSession(sessionId);
        return ResponseEntity.ok("Session Successfully Terminated");
    }

    @GetMapping("/send-signon")
    public ResponseEntity<String> sendSignon(@RequestParam String sessionId) {
        String outResponseString = "";

        try {
            outResponseString += "Try 01";

            byte[] isoMessage = iso8583Service.getSignonMessage();

            socketHandler.sendMessage(sessionId, isoMessage);

            outResponseString += " :: Success";

            return ResponseEntity.ok(outResponseString);
        } catch (UnknownHostException ex) {
            return ResponseEntity.status(500).body("Server not found: " + ex.getMessage());
        } catch (IOException ex) {
            return ResponseEntity.status(500).body("I/O error: " + ex.getMessage());
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("Generic Error" + ex.getMessage());
        }
    }
}
