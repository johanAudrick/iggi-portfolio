package com.ad.bridge.Controller;

import com.ad.bridge.Service.SocketService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/socket")
@AllArgsConstructor
public class SocketController {

    private SocketService socketService;

    @GetMapping("/connect")
    public ResponseEntity<String> connectSocket() {
        String socketSessionId = socketService.connectSocket();

        if (socketSessionId == null) {
            return ResponseEntity.status(500).body("Unable to Connect to Socket...");
        }

        return ResponseEntity.ok("WebSocket connection initiated. Check logs for connection status. Socket Session Id : " + socketService.connectSocket());
    }

    @GetMapping("/send")
    public ResponseEntity<String> sendMessageToClient(@RequestParam String sessionid, @RequestParam String message) {
        String messageStatus = socketService.sendMessageToSocket(sessionid, message);
        if(messageStatus == null) {
            return ResponseEntity.status(500).body("Unable to Send Message to Socket...");
        }

        return ResponseEntity.ok(messageStatus);
    }

    @GetMapping("/close")
    public ResponseEntity<String> closeSocketClient(@RequestParam String sessionId) {
        if(socketService.closeSocket(sessionId, "Manual Socket Close")) {
            return ResponseEntity.ok("Socket Closed Successfully");
        }
        return ResponseEntity.status(500).body("Issue while closing the socket ...");
    }
}
