package com.ad.bridge.Util;

import org.springframework.beans.factory.annotation.Value;

import java.net.URI;
import java.net.URISyntaxException;
import java.security.SecureRandom;

public class GeneralUtil {
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final SecureRandom secureRandom = new SecureRandom();

    private static final String SOCKET_HOST = "localhost";

    private static final String SOCKET_PORT = "8081";

    private static final String SOCKET_ENDPOINT = "/websocket";

    public static String generateRandomString(int length) {
        StringBuilder stringBuilder = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int randomIndex = secureRandom.nextInt(CHARACTERS.length());
            char randomChar = CHARACTERS.charAt(randomIndex);
            stringBuilder.append(randomChar);
        }

        return stringBuilder.toString();
    }

    public static URI generateSocketUri() {
        String url ="ws://" + SOCKET_HOST + ":" + SOCKET_PORT + SOCKET_ENDPOINT;
        System.out.println(url);
        try {
            return new URI(url);
        } catch (URISyntaxException ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
