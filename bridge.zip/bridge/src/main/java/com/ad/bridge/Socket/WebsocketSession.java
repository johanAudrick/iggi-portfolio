package com.ad.bridge.Socket;

import jakarta.servlet.http.HttpSession;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class WebsocketSession {
    /*  ------------------------------------------------------------------------------
        ------------------------- SOCKET SESSION HANDLER -----------------------------
        ------------------------------------------------------------------------------ */

    private Map<String, StompSession> activeSession;

    public WebsocketSession() {
        activeSession = new ConcurrentHashMap<>();
    }

    /*  --
        -- Creating New / Updating Existing Session
        --
    */
    public Map<String, WebsocketClientEndpoint> getOrCreateWebsocketClients() {
        HttpSession session = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest().getSession(true);
        Map<String, WebsocketClientEndpoint> websocketClients = (Map<String, WebsocketClientEndpoint>) session.getAttribute("websocketSession");

        if (websocketClients == null) {
            websocketClients = new ConcurrentHashMap<>();
            session.setAttribute("websocketSession", websocketClients);
        }

        return websocketClients;
    }

    /*  --
        -- Getting the Socket Client from the session stored
        --
    */
    public WebsocketClientEndpoint getWebSocketClient(String sessionId) {
        Map<String, WebsocketClientEndpoint> websocketClients = getOrCreateWebsocketClients();
        return websocketClients.get(sessionId);
    }

    /*  --
        -- Removing the Socket Client from the session
        --
    */
    public void removeWebSocketClient(String sessionId) {
        Map<String, WebsocketClientEndpoint> websocketClients = getOrCreateWebsocketClients();
        websocketClients.remove(sessionId);
    }
}
