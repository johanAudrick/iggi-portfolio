package com.ad.bridge.Service;

import com.ad.bridge.Socket.WebsocketClientEndpoint;
import com.ad.bridge.Socket.WebsocketSession;
import com.ad.bridge.Util.GeneralUtil;
import jakarta.websocket.CloseReason;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

@Component
public class SocketService {

    public String connectSocket() {
        String sessionId = null;

        WebsocketSession websocketSession = new WebsocketSession();

        System.out.println("Attempting to connect to WebSocket...");

        try {
            // open websocket
            final WebsocketClientEndpoint clientEndPoint = new WebsocketClientEndpoint(GeneralUtil.generateSocketUri());

            // add listener
            clientEndPoint.addMessageHandler(new WebsocketClientEndpoint.MessageHandler() {
                public void handleMessage(String message) {
                    // modify this function to read, convert and push the ISO 8583 Message to Queue
                    System.out.println(message);
                }
            });

            Map<String, WebsocketClientEndpoint> websocketClients = websocketSession.getOrCreateWebsocketClients();

            sessionId = GeneralUtil.generateRandomString(6);

            websocketClients.put(sessionId, clientEndPoint);
        } catch (Exception e) {
            System.out.println("Exception while connecting socket " + e.getMessage());
        } finally {
            return sessionId;
        }
    }

    public String sendMessageToSocket(String socketSessionId, String message) {
        WebsocketSession websocketSession = new WebsocketSession();
        if(websocketSession.getWebSocketClient(socketSessionId) != null) {
            websocketSession.getWebSocketClient(socketSessionId).sendMessage(message);
            return "Message Pocket Sent Successfully to Socket Server";
        }

        return null;
    }

    public boolean closeSocket(String socketSessionId, String closeReason) {
        WebsocketSession websocketSession = new WebsocketSession();
        if(websocketSession.getWebSocketClient(socketSessionId) != null) {
            CloseReason.CloseCodes closeCode = CloseReason.CloseCodes.NORMAL_CLOSURE;
            websocketSession.getWebSocketClient(socketSessionId).closeSocket(new CloseReason(closeCode, closeReason));
            websocketSession.removeWebSocketClient(socketSessionId);
            return true;
        }
        return false;
    }
}
