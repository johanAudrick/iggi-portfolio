package com.tcp.socket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTcpSocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
