package com.tcp.socket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

@SpringBootApplication
public class DemoTcpSocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTcpSocketApplication.class, args);
	}

	private static void startSocketServer() {
		int portNumber = 8888; // Choose any available port number

		try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
			System.out.println("Server is listening on port " + portNumber);

			while (true) {
				// Wait for a client to connect
				Socket clientSocket = serverSocket.accept();

				// Handle the client connection in a new thread
				new Thread(() -> handleClient(clientSocket)).start();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void handleClient(Socket clientSocket) {
		try (
				BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
				PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
		) {
			// Read the message from the client
			String clientMessage = (String) in.readLine();
			System.out.println("Received message from client: " + clientMessage);

			// Respond with "hi"
			out.println("hi");
			System.out.println("Sent response to client");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
