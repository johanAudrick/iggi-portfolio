package com.example.iso8583.dep.controller;

import com.example.iso8583.dep.util.GeneralUtil;
import com.example.iso8583.dep.util.WebsocketClientEndpoint;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/socket")
public class SocketController {

    private final Map<String, StompSession> activeSessions = new ConcurrentHashMap<>();

    private Map<String, WebsocketClientEndpoint> getOrCreateWebsocketClients() {
        HttpSession session = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest().getSession(true);
        Map<String, WebsocketClientEndpoint> websocketClients = (Map<String, WebsocketClientEndpoint>) session.getAttribute("websocketClients");

        if (websocketClients == null) {
            websocketClients = new ConcurrentHashMap<>();
            session.setAttribute("websocketClients", websocketClients);
        }

        return websocketClients;
    }

    private WebsocketClientEndpoint getWebSocketClient(String sessionId) {
        Map<String, WebsocketClientEndpoint> websocketClients = getOrCreateWebsocketClients();
        return websocketClients.get(sessionId);
    }

    @GetMapping("/connect")
    public ResponseEntity<String> connectSocket() {
        String uniqueSocketId = GeneralUtil.generateRandomString(5);
        String url = "ws://localhost:8080/websocket";

        System.out.println("Attempting to connect to WebSocket...");

        try {
            // open websocket
            final WebsocketClientEndpoint clientEndPoint = new WebsocketClientEndpoint(new URI("ws://localhost:8081/websocket"));

            // add listener
            clientEndPoint.addMessageHandler(new WebsocketClientEndpoint.MessageHandler() {
                public void handleMessage(String message) {
                    System.out.println(message);
                }
            });

            Map<String, WebsocketClientEndpoint> websocketClients = getOrCreateWebsocketClients();

            websocketClients.put(uniqueSocketId, clientEndPoint);

            // send message to websocket
            clientEndPoint.sendMessage("{'event':'addChannel','channel':'ok_btccny_ticker'}");

            // wait 5 seconds for messages from websocket
            Thread.sleep(5000);

        } catch (InterruptedException ex) {
            System.err.println("InterruptedException exception: " + ex.getMessage());
        } catch (URISyntaxException ex) {
            System.err.println("URISyntaxException exception: " + ex.getMessage());
        }

        return ResponseEntity.ok("WebSocket connection initiated. Check logs for connection status. Socket Session Id : " + uniqueSocketId);
    }

    @GetMapping("/send")
    public ResponseEntity<String> sendMessageToClient(@RequestParam String sessionid, @RequestParam String message) {
        if(getWebSocketClient(sessionid) != null) {
            getWebSocketClient(sessionid).sendMessage(message);
            return ResponseEntity.ok("Message Sent to client in session id " + sessionid);
        } else {
            return ResponseEntity.status(500).body("Session not found");
        }
    }
}
