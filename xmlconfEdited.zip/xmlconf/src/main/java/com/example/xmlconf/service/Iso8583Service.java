package com.example.xmlconf.service;

import com.example.xmlconf.config.Iso8583ConfigurationField;
import com.example.xmlconf.config.Iso8583ConfigurationReader;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@AllArgsConstructor
public class Iso8583Service {
    private final Iso8583ConfigurationReader iso8583ConfigurationReader;
    public void processConfig(){
        Map<String, Map<String, Iso8583ConfigurationField>> configMap = iso8583ConfigurationReader.getConfigMap("1100", "parse");
        Map<String, Iso8583ConfigurationField> fieldMap = configMap.get("1100");

        if (fieldMap != null) {
            for (Map.Entry<String, Iso8583ConfigurationField> entry : fieldMap.entrySet()) {
                String fieldNumber = entry.getKey();
                Iso8583ConfigurationField configElement = entry.getValue();

                System.out.println("Field Number: " + configElement.getId());
                System.out.println("  Data Type: " + configElement.getDataType());
                System.out.println("  Length Defined: " + configElement.isLengthDefinition());
                System.out.println("  Length: " + configElement.getLength());
            }
        } else {
            System.out.println("Configuration not found for field '1100'");
        }
    }
}
