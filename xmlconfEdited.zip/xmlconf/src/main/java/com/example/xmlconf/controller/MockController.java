package com.example.xmlconf.controller;

import com.example.xmlconf.service.Iso8583Service;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
@AllArgsConstructor
public class MockController {
    private final Iso8583Service iso8583Service;

    @GetMapping("/getConfig")
    public ResponseEntity<String> getConfigMethod() {
        iso8583Service.processConfig();
        return ResponseEntity.ok("Config Processed");
    }
}
