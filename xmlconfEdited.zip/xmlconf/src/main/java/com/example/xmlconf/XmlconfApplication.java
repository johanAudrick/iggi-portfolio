package com.example.xmlconf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlconfApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlconfApplication.class, args);
	}

}
