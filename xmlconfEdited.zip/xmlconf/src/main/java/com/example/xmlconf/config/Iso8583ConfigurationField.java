package com.example.xmlconf.config;

import lombok.Getter;

@Getter
public class Iso8583ConfigurationField {
    private final String id;
    private final String dataType;
    private final Integer length;
    private final boolean lengthDefinition;

    public Iso8583ConfigurationField(String id, String dataType, String length, boolean lengthDefinition) {

        if (dataType == null || length == null || dataType.isEmpty()) {
            throw new IllegalArgumentException("dataType and length cannot be null or empty");
        }

        Integer lengthInt = null;
        try {
            lengthInt = Integer.parseInt(length);
            if (lengthInt <= 0) {
                throw new IllegalArgumentException("length must be a positive integer");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Error parsing 'length' as an integer", e);
        }
        this.id = id;
        this.dataType = dataType;
        this.lengthDefinition = lengthDefinition;
        this.length = (lengthInt != null && lengthInt > 0) ? lengthInt : null;
    }
}
