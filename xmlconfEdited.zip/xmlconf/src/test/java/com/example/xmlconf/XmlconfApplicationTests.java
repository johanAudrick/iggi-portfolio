package com.example.xmlconf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlconfApplicationTests {

	@Test
	void contextLoads() {
	}

}
